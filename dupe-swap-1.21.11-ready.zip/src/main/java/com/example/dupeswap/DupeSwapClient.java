package com.example.dupeswap;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class DupeSwapClient implements ClientModInitializer {
    private static boolean enabled = false;

    // 25 swaps per second = one swap every 40 milliseconds.
    private static final long INTERVAL_NS = 40_000_000L;
    private static long nextSwap = 0L;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register(
            (dispatcher, registryAccess) -> registerCommands(dispatcher)
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!enabled || client.player == null || client.interactionManager == null) {
                return;
            }

            long now = System.nanoTime();
            if (now < nextSwap) {
                return;
            }

            nextSwap = now + INTERVAL_NS;
            swapMainAndOffhand(client);
        });
    }

    private static void registerCommands(
        CommandDispatcher<ClientCommandSource> dispatcher
    ) {
        dispatcher.register(
            literal("dupe")
                .then(literal("on").executes(ctx -> {
                    enabled = true;
                    nextSwap = System.nanoTime();
                    ctx.getSource().sendFeedback(
                        Text.literal("Dupe Swap ON - 25 swaps/sec")
                    );
                    return 1;
                }))
                .then(literal("off").executes(ctx -> {
                    enabled = false;
                    ctx.getSource().sendFeedback(
                        Text.literal("Dupe Swap OFF")
                    );
                    return 1;
                }))
        );
    }

    private static void swapMainAndOffhand(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) {
            return;
        }

        int hotbarSlot = client.player.getInventory().getSelectedSlot();

        // Player inventory slot 45 is the offhand slot.
        client.interactionManager.clickSlot(
            client.player.playerScreenHandler.syncId,
            45,
            hotbarSlot,
            SlotActionType.SWAP,
            client.player
        );
    }
}
